from odoo import models, fields

class MonProduit(models.Model):
    _inherit = 'product.template'

    allow_edit = fields.Boolean(string="Autoriser la modification de l'article")
